package com.dropall.client;

import java.util.List;

import com.dropall.DropAllMod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.ShulkerBoxScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;

public class DropAllClient implements ClientModInitializer {
	private static final int GUI_WIDTH = 176;
	private static final int BUTTON_WIDTH = 112;
	private static final int BUTTON_HEIGHT = 20;
	private static final int GAP = 2;

	@Override
	public void onInitializeClient() {
		ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
			int rows;
			if (screen instanceof GenericContainerScreen chest) {
				// Sandık (3 satır), büyük sandık (6 satır), ender sandığı (3 satır)
				rows = chest.getScreenHandler().getRows();
			} else if (screen instanceof ShulkerBoxScreen) {
				rows = 3;
			} else {
				return;
			}

			int guiLeft = (scaledWidth - GUI_WIDTH) / 2;
			int guiTop = (scaledHeight - (114 + rows * 18)) / 2;

			// Arayüzün sağ tarafı
			int x = Math.min(guiLeft + GUI_WIDTH + 6, scaledWidth - BUTTON_WIDTH - 2);
			int y = guiTop;

			List<ClickableWidget> buttons = Screens.getButtons(screen);

			buttons.add(new IconButton(x, y, Text.translatable("button.dropall.all"),
					new ItemStack(Items.DROPPER), b -> send(DropAllMod.ACTION_ALL)));

			buttons.add(new IconButton(x, y + (BUTTON_HEIGHT + GAP), Text.translatable("button.dropall.fireworks"),
					new ItemStack(Items.FIREWORK_ROCKET), b -> send(DropAllMod.ACTION_FIREWORKS)));

			buttons.add(new IconButton(x, y + 2 * (BUTTON_HEIGHT + GAP), Text.translatable("button.dropall.totems"),
					new ItemStack(Items.TOTEM_OF_UNDYING), b -> send(DropAllMod.ACTION_TOTEMS)));
		});
	}

	private static void send(int action) {
		PacketByteBuf buf = PacketByteBufs.create();
		buf.writeByte(action);
		ClientPlayNetworking.send(DropAllMod.DROP_PACKET, buf);
	}

	/** Minecraft butonu + solunda item ikonu. */
	private static class IconButton extends ButtonWidget {
		private final ItemStack icon;

		IconButton(int x, int y, Text message, ItemStack icon, PressAction onPress) {
			super(x, y, BUTTON_WIDTH, BUTTON_HEIGHT, message, onPress, DEFAULT_NARRATION_SUPPLIER);
			this.icon = icon;
		}

		@Override
		public void renderButton(DrawContext context, int mouseX, int mouseY, float delta) {
			super.renderButton(context, mouseX, mouseY, delta);
			context.drawItem(icon, this.getX() + 4, this.getY() + 2);
		}
	}
}
