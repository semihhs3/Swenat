package com.dropall;

import java.util.function.Predicate;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;

public class DropAllMod implements ModInitializer {
	public static final String MOD_ID = "dropall";
	public static final Identifier DROP_PACKET = new Identifier(MOD_ID, "drop");

	public static final int ACTION_ALL = 0;
	public static final int ACTION_FIREWORKS = 1;
	public static final int ACTION_TOTEMS = 2;

	@Override
	public void onInitialize() {
		ServerPlayNetworking.registerGlobalReceiver(DROP_PACKET, (server, player, handler, buf, responseSender) -> {
			int action = buf.readByte();
			server.execute(() -> handleDrop(player, action));
		});
	}

	private static void handleDrop(ServerPlayerEntity player, int action) {
		ScreenHandler screen = player.currentScreenHandler;

		// Sadece sandık / büyük sandık / ender sandığı (GenericContainer) ve shulker kutusu
		if (!(screen instanceof GenericContainerScreenHandler) && !(screen instanceof ShulkerBoxScreenHandler)) {
			return;
		}
		if (!screen.canUse(player)) {
			return;
		}

		Predicate<ItemStack> filter;
		if (action == ACTION_ALL) {
			filter = stack -> true;
		} else if (action == ACTION_FIREWORKS) {
			filter = stack -> stack.isOf(Items.FIREWORK_ROCKET);
		} else if (action == ACTION_TOTEMS) {
			filter = stack -> stack.isOf(Items.TOTEM_OF_UNDYING);
		} else {
			return;
		}

		boolean changed = false;
		for (Slot slot : screen.slots) {
			// Oyuncunun kendi envanteri hariç, sadece açılan kutunun slotları
			if (slot.inventory == player.getInventory()) {
				continue;
			}
			ItemStack stack = slot.getStack();
			if (stack.isEmpty() || !filter.test(stack) || !slot.canTakeItems(player)) {
				continue;
			}
			ItemStack toDrop = stack.copy();
			slot.setStack(ItemStack.EMPTY);
			throwStack(player, toDrop);
			changed = true;
		}

		if (changed) {
			screen.sendContentUpdates();
		}
	}

	/** Q tuşuyla item atmaya benzer şekilde oyuncunun baktığı yöne fırlatır. */
	private static void throwStack(ServerPlayerEntity player, ItemStack stack) {
		Random random = player.getRandom();
		ItemEntity entity = new ItemEntity(player.getWorld(), player.getX(), player.getEyeY() - 0.3, player.getZ(), stack);
		entity.setPickupDelay(40);

		float pitch = player.getPitch() * 0.017453292f;
		float yaw = player.getYaw() * 0.017453292f;
		float sinP = MathHelper.sin(pitch);
		float cosP = MathHelper.cos(pitch);
		float sinY = MathHelper.sin(yaw);
		float cosY = MathHelper.cos(yaw);
		float angle = random.nextFloat() * 6.2831855f;
		float spread = 0.02f * random.nextFloat();

		entity.setVelocity(
				-sinY * cosP * 0.3f + Math.cos(angle) * spread,
				-sinP * 0.3f + 0.1f + (random.nextFloat() - random.nextFloat()) * 0.1f,
				cosY * cosP * 0.3f + Math.sin(angle) * spread);

		player.getWorld().spawnEntity(entity);
	}
}
